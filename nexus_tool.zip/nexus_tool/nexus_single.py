#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║   🛡️  NEXUS - Advanced Utility Kit (Single File)             ║
║   Multi-Tool CLI for Termux & Linux                           ║
║   NO requirements.txt needed!                                ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import random
import string
import hashlib
import base64
import uuid
import socket
import re
import secrets
import subprocess
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

# ============== AUTO-INSTALL (NO requirements.txt needed) ==============
def install_deps():
    needed = {'requests': 'requests', 'colorama': 'colorama', 'pyfiglet': 'pyfiglet'}
    for mod, pkg in needed.items():
        try:
            __import__(mod)
        except ImportError:
            print(f"[*] Installing {pkg}...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except:
                subprocess.check_call(["pip", "install", pkg, "-q"],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

install_deps()

import requests
from colorama import init, Fore, Style
init(autoreset=True)
import pyfiglet

# ============== Colors ==============
class C:
    R  = Fore.RED; G  = Fore.GREEN; Y  = Fore.YELLOW; B  = Fore.BLUE
    M  = Fore.MAGENTA; CY = Fore.CYAN; W  = Fore.WHITE
    BR = Style.BRIGHT; X  = Style.RESET_ALL

# ============== Data ==============
DATA_DIR = Path.home() / ".nexus"
DATA_DIR.mkdir(exist_ok=True)
TM_FILE = DATA_DIR / "temp_mail.json"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Linux; Android 12; Termux) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Accept": "application/json, text/plain, */*",
})

# ============== UI ==============
def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    print(f"{C.CY}{pyfiglet.figlet_format('NEXUS', font='slant')}{C.X}")
    print(f"{C.R}{'═'*60}{C.X}")
    print(f"{C.Y}{C.BR}       🚀 NEXUS ADVANCED UTILITY KIT 🚀{C.X}")
    print(f"{C.R}{'═'*60}{C.X}")
    print(f"{C.G}  Version : {C.W}2.0 (Single File)")
    print(f"{C.G}  Status  : {C.W}Authorized Edition{C.X}")
    print(f"{C.R}{'═'*60}{C.X}\n")

def err(msg):  print(f"{C.R}[x] {msg}{C.X}")
def ok(msg):   print(f"{C.G}[✓] {msg}{C.X}")
def info(msg): print(f"{C.CY}[*] {msg}{C.X}")
def warn(msg): print(f"{C.Y}[!] {msg}{C.X}")
def head(t):
    print(f"\n{C.R}{'─'*60}\n{C.Y}  {t}\n{C.R}{'─'*60}{C.X}\n")
def back(): input(f"\n{C.Y}Press Enter to go back...{C.X}")
def pause(t=1): time.sleep(t)

# ============== Temp Mail (mail.tm primary, 2 fallbacks) ==============
def tm_get_domain():
    try:
        r = SESSION.get("https://api.mail.tm/domains", timeout=10)
        if r.status_code == 200:
            for d in r.json().get("hydra:member", []):
                if d.get("isActive") and not d.get("isPrivate"):
                    return d["domain"]
    except: pass
    return None

def tm_create():
    domain = tm_get_domain()
    if not domain: return None
    username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))
    address = f"{username}@{domain}"
    password = ''.join(random.choices(string.ascii_letters + string.digits, k=20))
    try:
        r = SESSION.post("https://api.mail.tm/accounts", 
                        json={"address": address, "password": password}, timeout=15)
        if r.status_code in (200, 201):
            tr = SESSION.post("https://api.mail.tm/token",
                            json={"address": address, "password": password}, timeout=15)
            if tr.status_code == 200:
                return {"service": "mail.tm", "address": address, "token": tr.json().get("token")}
    except: pass
    return None

def tm_inbox(token):
    try:
        r = SESSION.get("https://api.mail.tm/messages",
                       headers={"Authorization": f"Bearer {token}"}, timeout=10)
        if r.status_code == 200:
            return r.json().get("hydra:member", [])
    except: pass
    return []

def tm_read(token, mid):
    try:
        r = SESSION.get(f"https://api.mail.tm/messages/{mid}",
                       headers={"Authorization": f"Bearer {token}"}, timeout=10)
        if r.status_code == 200: return r.json()
    except: pass
    return None

def gma_get():
    try:
        r = SESSION.get("https://api.guerrillamail.com/ajax.php?f=get_email_address", timeout=10)
        if r.status_code == 200:
            d = r.json()
            return {"service": "guerrillamail", "address": d.get("email_addr"), "sid": d.get("sid_token")}
    except: pass
    return None

def gma_inbox(sid):
    try:
        r = SESSION.get(f"https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token={sid}", timeout=10)
        if r.status_code == 200: return r.json().get("mail_list", [])
    except: pass
    return []

def gma_read(sid, mid):
    try:
        r = SESSION.get(f"https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id={mid}&sid_token={sid}", timeout=10)
        if r.status_code == 200: return r.json()
    except: pass
    return None

# ============== Tools ==============
def tool_temp_mail():
    head("📧 TEMPORARY MAIL GENERATOR")
    info("Trying mail.tm → GuerrillaMail...")
    account = tm_create()
    service = "mail.tm"
    if not account:
        warn("mail.tm failed, trying GuerrillaMail...")
        account = gma_get()
        service = "guerrillamail"
    if not account:
        err("All services failed. Check internet.")
        back(); return
    TM_FILE.write_text(json.dumps(account, indent=2))
    ok("Email generated!")
    print(f"\n  {C.G}📬 Email: {C.W}{account['address']}")
    print(f"  {C.G}🔐 Service: {C.W}{service}")
    print(f"  {C.G}💾 Saved: {C.W}{TM_FILE}\n")
    if input(f"  {C.Y}Check inbox? (y/n): {C.X}").lower() == 'y':
        check_inbox(account, service)
    back()

def check_inbox(account, service):
    head(f"📥 INBOX ({service})")
    info("Fetching...")
    if service == "mail.tm":
        msgs = tm_inbox(account['token'])
    else:
        msgs = gma_inbox(account['sid'])
    if not msgs:
        warn("No messages"); back(); return
    ok(f"Found {len(msgs)} message(s)\n")
    for i, m in enumerate(msgs, 1):
        if service == "mail.tm":
            sender = m.get('from', {}).get('address', 'N/A')
            subj = m.get('subject', 'N/A')
        else:
            sender = m.get('mail_from', 'N/A')
            subj = m.get('mail_subject', 'N/A')
        print(f"  {C.CY}[{i}] {C.W}{subj}\n      {C.G}From: {C.W}{sender}\n")
    try:
        n = int(input(f"  {C.Y}Read which? (0=skip): {C.X}"))
        if n < 1 or n > len(msgs): return
        m = msgs[n-1]
        if service == "mail.tm":
            full = tm_read(account['token'], m['id'])
            body = (full or {}).get('text', '') or (full or {}).get('html', '') or '(empty)'
        else:
            full = gma_read(account['sid'], m['mail_id'])
            body = (full or {}).get('mail_body', '') or '(empty)'
        if body:
            head(f"📩 MESSAGE #{n}")
            body = re.sub(r'<[^>]+>', '', body)
            print(body[:3000])
    except: pass
    back()

def tool_ip():
    head("🌐 IP LOOKUP")
    ip = input(f"  {C.Y}IP (blank for yours): {C.X}").strip()
    if not ip:
        try: ip = SESSION.get("https://api.ipify.org", timeout=5).text
        except: err("Failed"); back(); return
    try:
        d = SESSION.get(f"http://ip-api.com/json/{ip}", timeout=10).json()
        if d.get("status") == "fail": err("Lookup failed")
        else:
            print(f"  {C.G}IP: {C.W}{d.get('query')}")
            print(f"  {C.G}Country: {C.W}{d.get('country')} ({d.get('countryCode')})")
            print(f"  {C.G}Region: {C.W}{d.get('regionName')}")
            print(f"  {C.G}City: {C.W}{d.get('city')}")
            print(f"  {C.G}ZIP: {C.W}{d.get('zip')}")
            print(f"  {C.G}Lat/Lon: {C.W}{d.get('lat')}, {d.get('lon')}")
            print(f"  {C.G}Timezone: {C.W}{d.get('timezone')}")
            print(f"  {C.G}ISP: {C.W}{d.get('isp')}")
            print(f"  {C.G}Org: {C.W}{d.get('org')}")
            print(f"  {C.G}AS: {C.W}{d.get('as')}")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_whois():
    head("🔍 WHOIS LOOKUP")
    dom = input(f"  {C.Y}Domain: {C.X}").strip().lower()
    if not dom: back(); return
    dom = dom.replace("http://","").replace("https://","").split("/")[0]
    try:
        r = SESSION.get(f"https://rdap.org/domain/{dom}", headers={"Accept":"application/json"}, timeout=10)
        if r.status_code == 200:
            d = r.json()
            events = {e.get("eventName"):e.get("eventDate","N/A") for e in d.get("events",[])}
            reg = "N/A"
            for ent in d.get("entities",[]):
                if "registrar" in ent.get("roles",[]):
                    vc = ent.get("vcardArray",[])
                    if vc and len(vc)>1:
                        for it in vc[1]:
                            if it[0]=="fn": reg=it[3]; break
                    break
            ns = ", ".join(n.get("ldhName","") for n in d.get("nameservers",[])[:3]) or "N/A"
            print(f"  {C.G}Domain: {C.W}{d.get('ldhName',dom)}")
            print(f"  {C.G}Registrar: {C.W}{reg}")
            print(f"  {C.G}Created: {C.W}{events.get('registration','N/A')}")
            print(f"  {C.G}Expires: {C.W}{events.get('expiration','N/A')}")
            print(f"  {C.G}Updated: {C.W}{events.get('last changed','N/A')}")
            print(f"  {C.G}Status: {C.W}{', '.join(d.get('status',[])) or 'N/A'}")
            print(f"  {C.G}NS: {C.W}{ns}")
        else: err(f"HTTP {r.status_code}")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_dns():
    head("📡 DNS LOOKUP")
    dom = input(f"  {C.Y}Domain: {C.X}").strip().lower()
    if not dom: back(); return
    dom = dom.replace("http://","").replace("https://","").split("/")[0]
    types = ['A','AAAA','MX','NS','TXT','CNAME']
    found = False
    for t in types:
        try:
            r = SESSION.get(f"https://dns.google/resolve?name={dom}&type={t}", timeout=10)
            d = r.json()
            if d.get("Answer"):
                found = True
                print(f"\n  {C.Y}[{t}]{C.X}")
                for a in d["Answer"][:5]:
                    print(f"    {C.W}→ {a.get('data','N/A')}{C.X}")
        except: continue
    if not found: err("No records")
    back()

def tool_port():
    head("🔌 PORT CHECKER")
    h = input(f"  {C.Y}Host: {C.X}").strip()
    p = input(f"  {C.Y}Port: {C.X}").strip()
    if not h or not p: back(); return
    try:
        port = int(p)
        s = socket.socket(); s.settimeout(5)
        r = s.connect_ex((h, port)); s.close()
        if r == 0: ok(f"Port {port} is OPEN on {h}")
        else: err(f"Port {port} is CLOSED on {h}")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_hash():
    head("🔐 HASH GENERATOR")
    t = input(f"  {C.Y}Text: {C.X}")
    if not t: back(); return
    print(f"\n  {C.G}MD5:    {C.W}{hashlib.md5(t.encode()).hexdigest()}")
    print(f"  {C.G}SHA1:   {C.W}{hashlib.sha1(t.encode()).hexdigest()}")
    print(f"  {C.G}SHA256: {C.W}{hashlib.sha256(t.encode()).hexdigest()}")
    print(f"  {C.G}SHA512: {C.W}{hashlib.sha512(t.encode()).hexdigest()}")
    back()

def tool_b64():
    head("🔐 BASE64")
    print(f"  {C.G}[1]{C.W} Encode  {C.G}[2]{C.W} Decode")
    m = input(f"  {C.Y}> {C.X}").strip()
    t = input(f"  {C.Y}Text: {C.X}")
    try:
        if m == "1": print(f"  {C.G}→ {C.W}{base64.b64encode(t.encode()).decode()}")
        elif m == "2": print(f"  {C.G}→ {C.W}{base64.b64decode(t).decode()}")
        else: err("Invalid")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_uuid():
    head("🎲 UUID GENERATOR")
    for _ in range(5):
        print(f"  {C.CY}→ {C.W}{uuid.uuid4()}")
    back()

def tool_password():
    head("🔑 PASSWORD GENERATOR")
    l = input(f"  {C.Y}Length (8-64, default 16): {C.X}").strip()
    try: length = max(8, min(64, int(l))) if l else 16
    except: length = 16
    chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+[]{}|;:,.<>?"
    pwd = ''.join(secrets.choice(chars) for _ in range(length))
    print(f"\n  {C.G}Password ({length}): {C.W}{pwd}")
    warn("Save it now!")
    back()

def tool_qr():
    head("📱 QR CODE")
    t = input(f"  {C.Y}Text/URL: {C.X}").strip()
    if not t: back(); return
    url = f"https://api.qrserver.com/v1/create-qr-code/?size=500x500&data={t}"
    qr_file = DATA_DIR / "qrcode.png"
    try:
        r = SESSION.get(url, timeout=15)
        if r.status_code == 200:
            qr_file.write_bytes(r.content)
            ok(f"Saved to: {qr_file}")
        else: err("Failed")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_shorten():
    head("🔗 URL SHORTENER")
    u = input(f"  {C.Y}URL: {C.X}").strip()
    if not u.startswith("http"): u = "https://" + u
    try:
        r = SESSION.get(f"https://tinyurl.com/api-create.php?url={u}", timeout=10)
        if "tinyurl" in r.text: ok(f"Short: {r.text}")
        else: err("Failed")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_github():
    head("🐙 GITHUB LOOKUP")
    u = input(f"  {C.Y}Username: {C.X}").strip()
    if not u: back(); return
    try:
        d = SESSION.get(f"https://api.github.com/users/{u}", timeout=10).json()
        if "message" in d: err("Not found")
        else:
            print(f"  {C.G}Name: {C.W}{d.get('name','N/A')}")
            print(f"  {C.G}Bio: {C.W}{d.get('bio','N/A')}")
            print(f"  {C.G}Location: {C.W}{d.get('location','N/A')}")
            print(f"  {C.G}Repos: {C.W}{d.get('public_repos',0)}")
            print(f"  {C.G}Followers: {C.W}{d.get('followers',0)}")
            print(f"  {C.G}Profile: {C.W}{d.get('html_url','N/A')}")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_weather():
    head("🌤️ WEATHER")
    c = input(f"  {C.Y}City: {C.X}").strip()
    if not c: back(); return
    try:
        r = SESSION.get(f"https://wttr.in/{c}?format=j1", timeout=15)
        d = r.json()
        if "current_condition" not in d: err("Failed")
        else:
            cur = d["current_condition"][0]
            print(f"  {C.G}Temp: {C.W}{cur.get('temp_C')}°C / {cur.get('temp_F')}°F")
            print(f"  {C.G}Feels: {C.W}{cur.get('FeelsLikeC')}°C")
            print(f"  {C.G}Condition: {C.W}{cur.get('weatherDesc',[{}])[0].get('value','N/A')}")
            print(f"  {C.G}Humidity: {C.W}{cur.get('humidity')}%")
            print(f"  {C.G}Wind: {C.W}{cur.get('windspeedKmph')} km/h")
    except Exception as e: err(f"Error: {e}")
    back()

def tool_sysinfo():
    head("📊 SYSTEM INFO")
    try:
        print(f"  {C.G}OS: {C.W}{sys.platform}")
        print(f"  {C.G}Python: {C.W}{sys.version.split()[0]}")
        print(f"  {C.G}Hostname: {C.W}{socket.gethostname()}")
        try:
            ip = SESSION.get("https://api.ipify.org", timeout=5).text
            print(f"  {C.G}Public IP: {C.W}{ip}")
        except: pass
        print(f"  {C.G}Time: {C.W}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    except Exception as e: err(f"Error: {e}")
    back()

# ============== Main Menu ==============
def main_menu():
    banner()
    print(f"{C.CY}  ╔══════════════════════════════════════════╗")
    print(f"{C.CY}  ║          {C.Y}SELECT AN OPTION{C.CY}                ║")
    print(f"{C.CY}  ╠══════════════════════════════════════════╣")
    print(f"{C.CY}  ║  {C.G}[1] {C.W} 📧 Temporary Mail                 {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[2] {C.W} 🌐 IP Address Lookup              {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[3] {C.W} 🔍 Website Whois                  {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[4] {C.W} 📡 DNS Records                    {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[5] {C.W} 🔌 Port Scanner                   {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[6] {C.W} 🔐 Hash Generator                 {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[7] {C.W} 🔑 Password Generator             {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[8] {C.W} 🔗 URL Shortener                  {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[9] {C.W} 📱 QR Code Generator              {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[10]{C.W} 🐙 GitHub Lookup                  {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[11]{C.W} 🌤️  Weather                      {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[12]{C.W} 📊 System Info                    {C.CY}║")
    print(f"{C.CY}  ║  {C.G}[0] {C.W} ❌ Exit                           {C.CY}║")
    print(f"{C.CY}  ╚══════════════════════════════════════════╝")
    return input(f"\n  {C.Y}nexus > {C.X}").strip()

# ============== Main Loop ==============
def main():
    tools = {
        "1": tool_temp_mail, "2": tool_ip, "3": tool_whois, "4": tool_dns,
        "5": tool_port, "6": tool_hash, "7": tool_password, "8": tool_shorten,
        "9": tool_qr, "10": tool_github, "11": tool_weather, "12": tool_sysinfo,
    }
    while True:
        try:
            ch = main_menu()
            if ch == "0":
                print(f"\n  {C.G}Bye! 👋{C.X}\n")
                sys.exit(0)
            elif ch in tools:
                tools[ch]()
            else:
                err("Invalid option!")
                pause()
        except KeyboardInterrupt:
            print(f"\n\n  {C.Y}Bye! 👋{C.X}\n")
            sys.exit(0)
        except Exception as e:
            err(f"Error: {e}")
            pause(2)

if __name__ == "__main__":
    main()
